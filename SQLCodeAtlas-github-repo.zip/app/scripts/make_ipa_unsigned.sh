#!/usr/bin/env bash
#
# Build an UNSIGNED .ipa for SQLCODE Atlas - useful for CI, for reviewing the
# artefact, and as the input for re-signing tools (Sideloadly, AltStore, Xcode).
#
# The produced IPA cannot be installed on a stock iPhone until it is re-signed
# with an Apple certificate/profile (see README ▸ “Getting a runnable IPA”).
#
# Requirements: macOS with Xcode (on Linux CI you cannot run this at all -
# the GitHub Actions workflow does it for you on a macOS runner).
#
# Usage: ./scripts/make_ipa_unsigned.sh
#
set -euo pipefail

PROJECT="${PROJECT:-SQLCodeAtlas.xcodeproj}"
SCHEME="${SCHEME:-SQLCodeAtlas}"
OUT_DIR="${OUT_DIR:-dist}"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "error: xcodebuild not found. Run this on macOS, or use the GitHub Actions workflow." >&2
  exit 1
fi

mkdir -p "$OUT_DIR"
DD="$OUT_DIR/DerivedData"
APP_DIR="$DD/Build/Products/Release-iphoneos"
rm -rf "$DD"

echo "▶︎ Building (unsigned)…"
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DD" \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGN_ENTITLEMENTS="" \
  ONLY_ACTIVE_ARCH=NO \
  build

APP="$APP_DIR/$SCHEME.app"
[[ -d "$APP" ]] || { echo "error: $APP not found" >&2; exit 1; }

STAGE="$OUT_DIR/ipa-stage"
rm -rf "$STAGE"
mkdir -p "$STAGE/Payload"
cp -R "$APP" "$STAGE/Payload/"

# make sure the bundled datasets really made it into the app
echo "▶︎ Bundled data:"
ls -la "$APP" | grep -E '\.json|Assets' || true

IPA="$OUT_DIR/$SCHEME-unsigned.ipa"
( cd "$STAGE" && zip -qry "../../$IPA" Payload )
rm -rf "$STAGE"

echo
echo "✅ Unsigned IPA: $IPA  ($(du -h "$IPA" | cut -f1))"
echo "   Re-sign for a device, e.g.:"
echo "     Sideloadly / AltStore: drag the IPA in and sign with your Apple ID"
echo "     Xcode:  open the project, set your team, and Run on the device"
