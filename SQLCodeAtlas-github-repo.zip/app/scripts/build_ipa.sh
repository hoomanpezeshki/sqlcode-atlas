#!/usr/bin/env bash
#
# Build a SIGNED .ipa for SQLCODE Atlas (Apple iOS).
#
# Requirements
#   * macOS with Xcode 15 or newer (`xcodebuild -version`)
#   * an Apple Developer account and a signing identity in your keychain
#   * the device UDIDs registered if you export an ad-hoc / development build
#
# Usage
#   DEVELOPMENT_TEAM=ABCDE12345 ./scripts/build_ipa.sh [development|ad-hoc|app-store]
#
# Optional environment variables
#   SCHEME        default SQLCodeAtlas
#   PROJECT       default SQLCodeAtlas.xcodeproj
#   OUT_DIR       default ./dist
#   BUNDLE_ID     default com.sqlcodeatlas.app
#
set -euo pipefail

PROJECT="${PROJECT:-SQLCodeAtlas.xcodeproj}"
SCHEME="${SCHEME:-SQLCodeAtlas}"
METHOD="${1:-development}"
OUT_DIR="${OUT_DIR:-dist}"
BUNDLE_ID="${BUNDLE_ID:-com.sqlcodeatlas.app}"

if [[ -z "${DEVELOPMENT_TEAM:-}" ]]; then
  echo "error: set DEVELOPMENT_TEAM (Apple Developer Team ID, 10 characters)." >&2
  exit 1
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "error: xcodebuild not found. This script must run on macOS with Xcode installed." >&2
  exit 1
fi

echo "▶︎ Xcode"
xcodebuild -version
echo "▶︎ Team : $DEVELOPMENT_TEAM   Scheme: $SCHEME   Method: $METHOD"

mkdir -p "$OUT_DIR"
ARCHIVE="$OUT_DIR/$SCHEME.xcarchive"
EXPORT_DIR="$OUT_DIR/ipa"
rm -rf "$ARCHIVE" "$EXPORT_DIR"
mkdir -p "$EXPORT_DIR"

echo "▶︎ Archiving…"
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath "$ARCHIVE" \
  DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  CODE_SIGN_STYLE=Automatic \
  -allowProvisioningUpdates \
  archive

echo "▶︎ Exporting IPA…"
cat > "$OUT_DIR/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key><string>${METHOD}</string>
  <key>teamID</key><string>${DEVELOPMENT_TEAM}</string>
  <key>signingStyle</key><string>automatic</string>
  <key>stripSwiftSymbols</key><true/>
  <key>compileBitcode</key><false/>
  <key>destination</key><string>export</string>
</dict>
</plist>
PLIST

xcodebuild -exportArchive \
  -archivePath "$ARCHIVE" \
  -exportPath "$EXPORT_DIR" \
  -exportOptionsPlist "$OUT_DIR/ExportOptions.plist" \
  -allowProvisioningUpdates

IPA="$(find "$EXPORT_DIR" -maxdepth 1 -name '*.ipa' | head -1)"
if [[ -z "$IPA" ]]; then
  echo "error: no .ipa produced - check the export log above." >&2
  exit 1
fi

echo
echo "✅ IPA ready: $IPA"
echo "   Install with:  xcrun devicectl device install app --device <DEVICE_ID> \"$IPA\""
echo "   or with Apple Configurator / Xcode ▸ Devices and Simulators, or upload to App Store Connect (Transporter)."
