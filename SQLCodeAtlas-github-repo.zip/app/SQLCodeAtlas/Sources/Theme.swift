//
//  Theme.swift
//  Visual language for SQLCodeAtlas (Db2 blue / terminal inspired, adaptive light & dark)
//

import SwiftUI
import UIKit

enum Theme {
    static let zos   = Color(red: 0.13, green: 0.35, blue: 0.72)   // Db2 blue
    static let luw   = Color(red: 0.10, green: 0.56, blue: 0.52)   // teal
    static let error = Color(red: 0.83, green: 0.22, blue: 0.20)
    static let warn  = Color(red: 0.86, green: 0.55, blue: 0.05)
    static let ok    = Color(red: 0.13, green: 0.60, blue: 0.35)
    static let nodata = Color(red: 0.35, green: 0.42, blue: 0.52)

    static func platform(_ p: DB2Platform) -> Color { p == .zos ? zos : luw }

    static func severityColor(_ s: CodeSeverity) -> Color {
        switch s {
        case .success: return ok
        case .nodata:  return nodata
        case .warning: return warn
        case .error:   return error
        }
    }

    static func severityColor(_ raw: String) -> Color {
        severityColor(CodeSeverity(rawValue: raw) ?? .error)
    }

    static let codeFont = Font.system(.title3, design: .monospaced).weight(.semibold)
    static let mono = Font.system(.callout, design: .monospaced)
    static let smallMono = Font.system(.footnote, design: .monospaced)
}

// MARK: - Card container

struct Card<Content: View>: View {
    var title: String? = nil
    var systemImage: String? = nil
    var accent: Color = .accentColor
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let title {
                HStack(spacing: 6) {
                    if let systemImage {
                        Image(systemName: systemImage)
                            .foregroundStyle(accent)
                    }
                    Text(title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                }
            }
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color(uiColor: .secondarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(Color.primary.opacity(0.07), lineWidth: 1)
        )
    }
}

// MARK: - Badges & chips

struct PlatformBadge: View {
    let platform: DB2Platform
    var compact = false

    var body: some View {
        Text(compact ? platform.shortTitle : platform.title)
            .font(.caption2.weight(.bold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(Theme.platform(platform).opacity(0.16))
            .foregroundStyle(Theme.platform(platform))
            .clipShape(Capsule())
            .overlay(Capsule().strokeBorder(Theme.platform(platform).opacity(0.35), lineWidth: 0.5))
            .accessibilityLabel("Platform \(platform.title)")
    }
}

struct SeverityBadge: View {
    let severity: CodeSeverity

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: severity.symbol).font(.caption2)
            Text(severity.title).font(.caption2.weight(.semibold))
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
        .background(Theme.severityColor(severity).opacity(0.14))
        .foregroundStyle(Theme.severityColor(severity))
        .clipShape(Capsule())
    }
}

struct SQLStateChip: View {
    let value: String
    var body: some View {
        Text(value)
            .font(Theme.smallMono.weight(.semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(Color.accentColor.opacity(0.12))
            .foregroundStyle(Color.accentColor)
            .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
            .accessibilityLabel("SQLSTATE \(value)")
    }
}

struct TagChip: View {
    let text: String
    var color: Color = .secondary
    var body: some View {
        Text(text)
            .font(.caption2)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color.opacity(0.12))
            .foregroundStyle(color)
            .clipShape(Capsule())
    }
}

// MARK: - Copy button with feedback

struct CopyButton: View {
    let text: String
    var label: String = "Copy"
    @State private var copied = false

    var body: some View {
        Button {
            UIPasteboard.general.string = text
            withAnimation { copied = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                withAnimation { copied = false }
            }
        } label: {
            Label(copied ? "Copied" : label, systemImage: copied ? "checkmark" : "doc.on.doc")
                .font(.footnote.weight(.medium))
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .tint(copied ? Theme.ok : .accentColor)
    }
}

// MARK: - Code sample block

struct CodeBlock: View {
    let code: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ScrollView(.horizontal, showsIndicators: false) {
                Text(code)
                    .font(Theme.smallMono)
                    .textSelection(.enabled)
                    .padding(12)
            }
            CopyButton(text: code, label: "Copy SQL")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(uiColor: .tertiarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

// MARK: - List row for a code

struct CodeRow: View {
    let code: DB2Code
    var showPlatform = true

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 2) {
                Text(code.codeLabel)
                    .font(Theme.codeFont)
                    .foregroundStyle(Theme.severityColor(code.severity))
                if showPlatform {
                    Text(code.platform.shortTitle)
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(Theme.platform(code.platform))
                }
            }
            .frame(minWidth: 58, alignment: .trailing)

            VStack(alignment: .leading, spacing: 3) {
                Text(code.t)
                    .font(.subheadline)
                    .lineLimit(2)
                HStack(spacing: 6) {
                    if let st = code.primarySQLState { SQLStateChip(value: st) }
                    if let mid = code.m { TagChip(text: mid) }
                    Text(code.k).font(.caption2).foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Simple bulleted / numbered lists

struct BulletList: View {
    let items: [String]
    var symbol: String = "circle.fill"
    var tint: Color = .accentColor

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(items.indices, id: \.self) { index in
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: symbol)
                        .font(.system(size: 6))
                        .foregroundStyle(tint)
                        .padding(.top, 6)
                    Text(items[index])
                        .font(.subheadline)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }
}

struct NumberedList: View {
    let items: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(items.indices, id: \.self) { index in
                HStack(alignment: .top, spacing: 8) {
                    Text("\(index + 1)")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(width: 18, height: 18)
                        .background(Circle().fill(Theme.ok))
                    Text(items[index])
                        .font(.subheadline)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }
}
