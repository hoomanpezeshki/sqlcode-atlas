//
//  Models.swift
//  SQLCodeAtlas — Db2 for z/OS and Db2 for LUW SQLCODE reference
//

import Foundation

// MARK: - Platform

enum DB2Platform: String, Codable, CaseIterable, Identifiable, Hashable {
    case zos
    case luw

    var id: String { rawValue }

    var title: String {
        switch self {
        case .zos: return "Db2 z/OS"
        case .luw: return "Db2 LUW"
        }
    }

    var shortTitle: String {
        switch self {
        case .zos: return "z/OS"
        case .luw: return "LUW"
        }
    }

    var accent: String {
        switch self {
        case .zos: return "z/OS"
        case .luw: return "LUW"
        }
    }
}

// MARK: - Severity

enum CodeSeverity: String, Codable, CaseIterable, Identifiable, Hashable {
    case success
    case nodata
    case warning
    case error

    var id: String { rawValue }

    var title: String {
        switch self {
        case .success: return "Success"
        case .nodata:  return "No data"
        case .warning: return "Warning"
        case .error:   return "Error"
        }
    }

    var symbol: String {
        switch self {
        case .success: return "checkmark.seal.fill"
        case .nodata:  return "tray"
        case .warning: return "exclamationmark.triangle.fill"
        case .error:   return "xmark.octagon.fill"
        }
    }
}

// MARK: - A single SQLCODE entry (one platform)

struct DB2Code: Identifiable, Codable, Hashable {
    let c: Int              // SQLCODE (signed; +100 stored as 100)
    let t: String           // message text (z/OS: upper case message; LUW: message text)
    let s: [String]         // SQLSTATE values
    let m: String?          // LUW message id, e.g. SQL0803N
    let v: String?          // LUW severity letter (N/W/I/C/E)
    let k: String           // category derived from the SQLSTATE class
    let g: String           // severity group: success | nodata | warning | error
    let hint: String?       // class level advice (applies to every code)
    let platform: DB2Platform

    var id: String { "\(platform.rawValue):\(c)" }

    var codeLabel: String {
        if c > 0 { return "+\(c)" }
        return "\(c)"
    }

    var searchCode: String { "\(abs(c))" }

    var severity: CodeSeverity { CodeSeverity(rawValue: g) ?? .error }

    var primarySQLState: String? { s.first }

    enum CodingKeys: String, CodingKey { case c, t, s, m, v, k, g, hint }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        c = try box.decode(Int.self, forKey: .c)
        t = try box.decode(String.self, forKey: .t)
        s = (try? box.decode([String].self, forKey: .s)) ?? []
        m = try? box.decodeIfPresent(String.self, forKey: .m)
        v = try? box.decodeIfPresent(String.self, forKey: .v)
        k = (try? box.decode(String.self, forKey: .k)) ?? "SQL error"
        g = (try? box.decode(String.self, forKey: .g)) ?? "error"
        hint = try? box.decodeIfPresent(String.self, forKey: .hint)
        platform = .zos   // replaced right after decoding by the data store
    }

    init(c: Int, t: String, s: [String], m: String?, v: String?, k: String, g: String, hint: String?, platform: DB2Platform) {
        self.c = c; self.t = t; self.s = s; self.m = m; self.v = v
        self.k = k; self.g = g; self.hint = hint; self.platform = platform
    }

    func withPlatform(_ p: DB2Platform) -> DB2Code {
        DB2Code(c: c, t: t, s: s, m: m, v: v, k: k, g: g, hint: hint, platform: p)
    }

    func encode(to encoder: Encoder) throws {
        var box = encoder.container(keyedBy: CodingKeys.self)
        try box.encode(c, forKey: .c)
        try box.encode(t, forKey: .t)
        try box.encode(s, forKey: .s)
        try box.encodeIfPresent(m, forKey: .m)
        try box.encodeIfPresent(v, forKey: .v)
        try box.encode(k, forKey: .k)
        try box.encode(g, forKey: .g)
        try box.encodeIfPresent(hint, forKey: .hint)
    }
}

// MARK: - Authored troubleshooting guidance

struct ReasonCode: Codable, Hashable, Identifiable {
    let code: String
    let meaning: String
    var id: String { code }
}

struct Guidance: Codable, Hashable {
    var summary: String?
    var causes: [String]?
    var fixes: [String]?
    var example: String?
    var seeAlso: [String]?
    var reasonCodes: [ReasonCode]?

    var isEmpty: Bool {
        (summary?.isEmpty ?? true) && (causes?.isEmpty ?? true) && (fixes?.isEmpty ?? true) &&
        example == nil && (seeAlso?.isEmpty ?? true) && (reasonCodes?.isEmpty ?? true)
    }
}

/// guidance.json is a dictionary of dictionaries: { "any": { "-803": {...} }, "zos": {...}, "luw": {...} }
typealias GuidanceFile = [String: [String: Guidance]]

// MARK: - SQLSTATE reference

struct SQLStateClass: Codable, Hashable, Identifiable {
    let c: String          // class code, e.g. "23"
    let t: String          // title
    let d: String          // description
    let a: String?         // typical action
    let codes: [String]?   // representative SQLCODEs
    let sev: String?       // severity group
    var id: String { c }
}

struct SQLStateValue: Codable, Hashable, Identifiable {
    let v: String          // 5 char SQLSTATE
    let t: String          // meaning
    let codes: [String]?   // typical SQLCODEs
    var id: String { v }
}

struct SQLStateFile: Codable {
    let classes: [SQLStateClass]
    let specific: [SQLStateValue]
}

// MARK: - SQL statement library

struct StatementCategory: Codable, Hashable, Identifiable {
    let name: String
    var id: String { name }
}

struct SQLStatement: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let cat: String
    let plat: [String]
    let tpl: String
    let notes: String?
    let tags: [String]?
    let e: String?

    var platforms: [DB2Platform] {
        plat.compactMap { DB2Platform(rawValue: $0) }
    }

    var platformLabel: String {
        let names = platforms.map { $0.shortTitle }
        return names.isEmpty ? "both" : names.joined(separator: " + ")
    }
}

struct StatementFile: Codable {
    let categories: [String]
    let statements: [SQLStatement]
}

// MARK: - Meta

struct MetaFile: Codable {
    struct PlatformStats: Codable {
        let codes: Int
        let negatives: Int
        let positives: Int
        let sqlstates: Int
    }
    let generated: String
    let zos: PlatformStats
    let luw: PlatformStats
    let statements: Int
    let sqlstate_classes: Int
    let sqlstate_values: Int
}

// MARK: - Search hit

struct CodeHit: Identifiable, Hashable {
    enum MatchKind: Int {
        case exactCode = 0
        case codePrefix = 1
        case sqlstate = 2
        case messageID = 3
        case message = 4
        case category = 5
    }

    let code: DB2Code
    let kind: MatchKind
    var id: String { code.id }
}
