//
//  HomeView.swift
//  Dashboard: quick search, coverage stats, most-used codes, bookmarks.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: DataStore
    @EnvironmentObject private var favourites: FavouritesStore

    @State private var query = ""
    @State private var platform: DB2Platform? = nil

    private let quickCodes = [-104, -204, -803, -811, -805, -551, -530, -407, -911, -922, -302, -305]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    header

                    searchField

                    if !query.isEmpty {
                        searchResults
                    } else {
                        statsCard
                        quickAccessCard
                        if !favourites.ids.isEmpty { favouritesCard }
                        tipsCard
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("SQLCODE Atlas")
            .navigationDestination(for: Route.self) { route in
                RouteView(route: route)
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Picker("Platform", selection: $platform) {
                            Text("Both platforms").tag(DB2Platform?.none)
                            Text("Db2 z/OS").tag(DB2Platform?.some(.zos))
                            Text("Db2 LUW").tag(DB2Platform?.some(.luw))
                        }
                    } label: {
                        Label("Platform", systemImage: "line.3.horizontal.decrease.circle")
                    }
                }
            }
        }
    }

    // MARK: - Sections

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Db2 SQLCODE reference")
                .font(.title2.weight(.bold))
            Text("Offline lookup for Db2 for z/OS and Db2 for Linux, UNIX and Windows — codes, SQLSTATEs, causes, fixes and SQL statements.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 8)
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("−803, 23505, SQL0803N, deadlock…", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)
            if !query.isEmpty {
                Button {
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                }
            }
        }
        .padding(12)
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    @ViewBuilder
    private var searchResults: some View {
        let hits = store.search(query, platform: platform)
        if hits.isEmpty {
            Card(title: "No match", systemImage: "questionmark.circle") {
                Text("Nothing found for “\(query)”. Try a SQLCODE (−803), a SQLSTATE (23505), a LUW message id (SQL0803N) or a keyword such as “deadlock”, “cursor”, “truncation”.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        } else {
            VStack(alignment: .leading, spacing: 8) {
                Text("\(hits.count) match\(hits.count == 1 ? "" : "es")")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                ForEach(hits.prefix(60)) { hit in
                    NavigationLink(value: Route.code(hit.code)) {
                        CodeRow(code: hit.code)
                    }
                    .buttonStyle(.plain)
                    Divider()
                }
                if hits.count > 60 {
                    Text("Refine the search to see more specific matches.").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(14)
            .background(Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    private var statsCard: some View {
        Card(title: "Coverage", systemImage: "chart.bar.doc.horizontal") {
            HStack(spacing: 12) {
                statTile(value: "\(store.zosCodes.count)", label: "z/OS codes", color: Theme.zos)
                statTile(value: "\(store.luwCodes.count)", label: "LUW codes", color: Theme.luw)
                statTile(value: "\(store.statements?.statements.count ?? 0)", label: "SQL snippets", color: Theme.ok)
            }
            Text("Every code carries its message text, SQLSTATE(s), error class and the troubleshooting actions for that class. Guidance written by hand is included for the codes you meet most often in production.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func statTile(value: String, label: String, color: Color) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.title3.weight(.bold)).foregroundStyle(color)
            Text(label).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(color.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private var quickAccessCard: some View {
        Card(title: "Most used codes", systemImage: "bolt") {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 84), spacing: 8)], spacing: 8) {
                ForEach(quickCodes, id: \.self) { value in
                    let target = store.zosCodes.first { $0.c == value } ?? store.luwCodes.first { $0.c == value }
                    if let target {
                        NavigationLink(value: Route.code(target)) {
                            VStack(spacing: 2) {
                                Text(target.codeLabel)
                                    .font(.system(.subheadline, design: .monospaced).weight(.bold))
                                Text(target.k)
                                    .font(.system(size: 9))
                                    .lineLimit(1)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(Theme.severityColor(target.severity).opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var favouritesCard: some View {
        Card(title: "Bookmarked codes", systemImage: "bookmark.fill") {
            let all = store.allCodes.filter { favourites.ids.contains($0.id) }
            VStack(alignment: .leading, spacing: 0) {
                ForEach(all) { code in
                    NavigationLink(value: Route.code(code)) {
                        CodeRow(code: code)
                    }
                    .buttonStyle(.plain)
                    if code.id != all.last?.id { Divider() }
                }
            }
        }
    }

    private var tipsCard: some View {
        Card(title: "Tips", systemImage: "lightbulb") {
            BulletList(items: [
                "Type just the number: 803 finds SQLCODE −803 on both platforms.",
                "Search by SQLSTATE (23505) to see every code in that class.",
                "Search by LUW message id (SQL0803N) or by symptom (“cursor”, “timeout”, “truncation”).",
                "Open a code and swipe the platform control to compare the z/OS and LUW descriptions.",
                "The Statements tab has ready-to-copy SQL for batch, procedures, diagnostics and DBA checks."
            ])
        }
    }
}
