//
//  RouteView.swift
//  Central destination resolver used by every NavigationStack in the app.
//

import SwiftUI

struct RouteView: View {
    let route: Route

    var body: some View {
        switch route {
        case .code(let code):
            CodeDetailView(code: code)
        case .sqlstate(let value):
            SQLStateDetailView(value: value)
        case .sqlstateClass(let cls):
            SQLStateClassDetailView(cls: cls)
        case .statement(let statement):
            StatementDetailView(statement: statement)
        }
    }
}
