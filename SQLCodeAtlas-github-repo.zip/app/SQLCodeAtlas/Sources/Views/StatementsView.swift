//
//  StatementsView.swift
//  Ready-to-copy SQL statements for z/OS and LUW: batch, procedures, diagnostics, DBA tasks.
//

import SwiftUI

struct StatementsView: View {
    @EnvironmentObject private var store: DataStore
    @State private var query = ""

    private var grouped: [(String, [SQLStatement])] {
        guard let file = store.statements else { return [] }
        let all = file.statements
        let filtered: [SQLStatement]
        if query.trimmingCharacters(in: .whitespaces).isEmpty {
            filtered = all
        } else {
            let q = query.lowercased()
            filtered = all.filter { s in
                s.name.lowercased().contains(q) ||
                s.tpl.lowercased().contains(q) ||
                (s.notes ?? "").lowercased().contains(q) ||
                (s.tags ?? []).contains { $0.lowercased().contains(q) }
            }
        }
        return file.categories.compactMap { cat in
            let items = filtered.filter { $0.cat == cat }
            return items.isEmpty ? nil : (cat, items)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(grouped.indices, id: \.self) { index in
                    Section(grouped[index].0) {
                        ForEach(grouped[index].1) { stmt in
                            NavigationLink(value: Route.statement(stmt)) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(stmt.name).font(.subheadline.weight(.semibold))
                                    HStack(spacing: 6) {
                                        ForEach(stmt.platforms) { p in
                                            Text(p.shortTitle)
                                                .font(.system(size: 9, weight: .bold))
                                                .padding(.horizontal, 6).padding(.vertical, 2)
                                                .background(Theme.platform(p).opacity(0.15))
                                                .foregroundStyle(Theme.platform(p))
                                                .clipShape(Capsule())
                                        }
                                        if let tags = stmt.tags, let first = tags.first {
                                            Text(first).font(.caption2).foregroundStyle(.secondary)
                                        }
                                    }
                                }
                                .padding(.vertical, 2)
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .searchable(text: $query, prompt: "Statement, keyword or symptom")
            .navigationTitle("SQL statements")
            .navigationDestination(for: Route.self) { RouteView(route: $0) }
        }
    }
}

struct StatementDetailView: View {
    let statement: SQLStatement

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(statement.name).font(.title3.weight(.bold))
                    HStack(spacing: 6) {
                        TagChip(text: statement.cat, color: .accentColor)
                        ForEach(statement.platforms) { p in PlatformBadge(platform: p) }
                    }
                }
                .padding(.top, 4)

                Card(title: "SQL", systemImage: "curlybraces", accent: Theme.zos) {
                    CodeBlock(code: statement.tpl)
                }

                if let e = statement.e, !e.isEmpty {
                    Card(title: "Alternative / extra", systemImage: "plus.rectangle.on.rectangle", accent: Theme.luw) {
                        CodeBlock(code: e)
                    }
                }

                if let notes = statement.notes, !notes.isEmpty {
                    Card(title: "Notes & gotchas", systemImage: "exclamationmark.bubble", accent: Theme.warn) {
                        Text(notes)
                            .font(.subheadline)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                if let tags = statement.tags, !tags.isEmpty {
                    Card(title: "Tags", systemImage: "tag") {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 6) {
                                ForEach(tags, id: \.self) { TagChip(text: $0) }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 24)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle(statement.cat)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                ShareLink(item: statement.tpl) { Image(systemName: "square.and.arrow.up") }
            }
        }
    }
}
