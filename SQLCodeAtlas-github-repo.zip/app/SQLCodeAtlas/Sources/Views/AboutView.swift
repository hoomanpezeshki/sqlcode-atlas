//
//  AboutView.swift
//  Coverage, sources, attribution and how to use the app.
//

import SwiftUI

struct AboutView: View {
    @EnvironmentObject private var store: DataStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {

                    VStack(alignment: .leading, spacing: 6) {
                        HStack(spacing: 10) {
                            Image(systemName: "number.square.fill")
                                .font(.system(size: 34))
                                .foregroundStyle(Theme.zos)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("SQLCODE Atlas").font(.title2.weight(.bold))
                                Text("Db2 for z/OS · Db2 for LUW")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Text("An offline reference for SQLCODEs, SQLSTATEs and the SQL you actually write when something breaks in production.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 8)

                    Card(title: "What is inside", systemImage: "shippingbox", accent: Theme.zos) {
                        if let meta = store.meta {
                            VStack(alignment: .leading, spacing: 10) {
                                row("Db2 for z/OS SQLCODEs", "\(meta.zos.codes)")
                                row("Db2 for LUW SQLCODEs", "\(meta.luw.codes)")
                                row("Distinct SQLSTATEs", "\(meta.zos.sqlstates + meta.luw.sqlstates)")
                                row("Hand-written troubleshooting entries", "\(store.guidance.count)")
                                row("SQLSTATE classes / values", "\(meta.sqlstate_classes) / \(meta.sqlstate_values)")
                                row("SQL statement snippets", "\(meta.statements)")
                                Text("Negative codes are errors, 0 is success, +100 means ‘no row found’ and other positive codes are warnings. Every entry shows the platform, the message text, the SQLSTATE(s) and the class-level action; the codes you meet most often also carry causes, fixes, examples and reason codes.")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        } else {
                            Text("Dataset statistics are unavailable.").font(.footnote)
                        }
                    }

                    Card(title: "Search tips", systemImage: "magnifyingglass") {
                        BulletList(items: [
                            "803 or −803 — exact code lookup on both platforms.",
                            "23505 — all codes raising that SQLSTATE.",
                            "SQL0803N — LUW message identifier.",
                            "deadlock, truncation, cursor not open — full-text search in message text and class.",
                            "Use the Filter menu in SQLCODEs to limit by severity, class or to the codes with written guidance."
                        ])
                    }

                    Card(title: "How this data was built", systemImage: "hammer", accent: Theme.luw) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Code numbers, message text and SQLSTATE values are derived from IBM's published Db2 codes/messages documentation, machine-extracted and normalised into JSON that ships inside the app (no network access required).")
                            Text("Causes, fixes, examples, reason-code explanations, the SQLSTATE class advice and all SQL snippets are original material written for this app, focused on what to check first in a real incident.")
                            Text("Because Db2 evolves, treat the message text as a starting point and always confirm against the documentation for your exact release and function level.")
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    }

                    Card(title: "Attribution & disclaimer", systemImage: "text.badge.checkmark") {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("IBM, Db2, z/OS and DB2 are trademarks of International Business Machines Corporation. Message identifiers, message text and SQLSTATE values originate from IBM Db2 documentation and remain the property of IBM.")
                            Text("This app is an independent, unofficial reference for personal/educational use. It is not affiliated with, endorsed by, or supported by IBM. Verify anything you change in a production system against your own change process.")
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    }

                    Card(title: "Official documentation", systemImage: "book") {
                        VStack(alignment: .leading, spacing: 10) {
                            Link(destination: URL(string: "https://www.ibm.com/docs/en/db2-for-zos/13?topic=db2-codes")!) {
                                Label("Db2 for z/OS — Codes", systemImage: "arrow.up.right.square").font(.footnote)
                            }
                            Link(destination: URL(string: "https://www.ibm.com/docs/en/db2/11.5.x?topic=messages-sql-codes")!) {
                                Label("Db2 for LUW — SQL codes", systemImage: "arrow.up.right.square").font(.footnote)
                            }
                            Link(destination: URL(string: "https://www.ibm.com/docs/en/db2-for-zos/13?topic=codes-sqlstate-values-common-error")!) {
                                Label("SQLSTATE values and common error codes", systemImage: "arrow.up.right.square").font(.footnote)
                            }
                            Link(destination: URL(string: "https://www.ibm.com/docs/en/db2/11.5.x?topic=reference-sqlstate")!) {
                                Label("Db2 LUW — SQLSTATE reference", systemImage: "arrow.up.right.square").font(.footnote)
                            }
                        }
                    }

                    Card(title: "Version", systemImage: "info.circle") {
                        VStack(alignment: .leading, spacing: 6) {
                            row("App version", Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0")
                            row("Dataset generated", store.meta?.generated ?? "2026-09-21")
                            row("Platforms", "Db2 for z/OS 11/12/13, Db2 for LUW 11.5 (codes are also valid for 10.5/11.1)")
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("About")
        }
    }

    private func row(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).font(.subheadline)
            Spacer()
            Text(value).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
        }
    }
}
