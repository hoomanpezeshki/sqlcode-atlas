//
//  CodesView.swift
//  Browse and filter the complete SQLCODE catalogue.
//

import SwiftUI

struct CodesView: View {
    @EnvironmentObject private var store: DataStore

    @State private var query = ""
    @State private var platform: DB2Platform? = nil
    @State private var severityFilter: String = "all"   // all | error | warning | nodata | success
    @State private var category: String? = nil
    @State private var showOnlyDocumented = false

    private var results: [DB2Code] {
        var list: [DB2Code]

        if query.trimmingCharacters(in: .whitespaces).isEmpty {
            list = store.codes(for: platform)
        } else {
            list = store.search(query, platform: platform).map { $0.code }
        }

        if severityFilter != "all" {
            list = list.filter { $0.g == severityFilter }
        }
        if let category {
            list = list.filter { $0.k == category }
        }
        if showOnlyDocumented {
            list = list.filter { store.hasAuthoredGuidance($0) }
        }
        return list
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Platform", selection: $platform) {
                        Text("Both").tag(DB2Platform?.none)
                        Text("z/OS").tag(DB2Platform?.some(.zos))
                        Text("LUW").tag(DB2Platform?.some(.luw))
                    }
                    .pickerStyle(.segmented)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
                }

                Section {
                    ForEach(results) { code in
                        NavigationLink(value: Route.code(code)) {
                            CodeRow(code: code, showPlatform: platform == nil)
                        }
                    }
                    if results.isEmpty {
                        Text("No codes match the current filters.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("\(results.count) code\(results.count == 1 ? "" : "s")")
                }
            }
            .listStyle(.plain)
            .searchable(text: $query, prompt: "Search code, SQLSTATE, message text")
            .navigationTitle("SQLCODEs")
            .navigationDestination(for: Route.self) { RouteView(route: $0) }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Picker("Severity", selection: $severityFilter) {
                            Text("All severities").tag("all")
                            Text("Errors only").tag("error")
                            Text("Warnings only").tag("warning")
                            Text("No data").tag("nodata")
                            Text("Success").tag("success")
                        }
                        Divider()
                        Picker("Class", selection: $category) {
                            Text("All classes").tag(String?.none)
                            ForEach(store.categories, id: \.self) { c in
                                Text(c).tag(String?.some(c))
                            }
                        }
                        Divider()
                        Toggle("Only codes with written guidance", isOn: $showOnlyDocumented)
                    } label: {
                        Label("Filter", systemImage: "line.3.horizontal.decrease.circle")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    if severityFilter != "all" || category != nil || showOnlyDocumented {
                        Button("Clear") {
                            severityFilter = "all"; category = nil; showOnlyDocumented = false
                        }
                    }
                }
            }
        }
    }
}
