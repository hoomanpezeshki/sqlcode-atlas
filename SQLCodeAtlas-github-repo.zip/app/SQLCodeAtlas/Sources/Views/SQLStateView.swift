//
//  SQLStateView.swift
//  SQLSTATE class reference and drill-down from a state to the codes that raise it.
//

import SwiftUI

struct SQLStateView: View {
    @EnvironmentObject private var store: DataStore
    @State private var query = ""
    @State private var mode = 0   // 0 = classes, 1 = specific values

    var body: some View {
        NavigationStack {
            Group {
                if let file = store.sqlState {
                    List {
                        Section {
                            Picker("View", selection: $mode) {
                                Text("Classes").tag(0)
                                Text("Values").tag(1)
                            }
                            .pickerStyle(.segmented)
                            .listRowInsets(EdgeInsets(top: 6, leading: 0, bottom: 6, trailing: 0))
                            .listRowBackground(Color.clear)
                        }

                        if mode == 0 {
                            ForEach(filteredClasses(file)) { cls in
                                NavigationLink(value: Route.sqlstateClass(cls)) {
                                    classRow(cls)
                                }
                            }
                        } else {
                            ForEach(filteredValues(file)) { v in
                                NavigationLink(value: Route.sqlstate(v.v)) {
                                    valueRow(v)
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                } else {
                    ProgressView()
                }
            }
            .searchable(text: $query, prompt: "Class, value or meaning")
            .navigationTitle("SQLSTATE")
            .navigationDestination(for: Route.self) { RouteView(route: $0) }
        }
    }

    private func filteredClasses(_ file: SQLStateFile) -> [SQLStateClass] {
        guard !query.isEmpty else { return file.classes }
        let q = query.lowercased()
        return file.classes.filter { $0.c.lowercased().contains(q) || $0.t.lowercased().contains(q) || $0.d.lowercased().contains(q) }
    }

    private func filteredValues(_ file: SQLStateFile) -> [SQLStateValue] {
        guard !query.isEmpty else { return file.specific }
        let q = query.lowercased()
        return file.specific.filter { $0.v.lowercased().contains(q) || $0.t.lowercased().contains(q) }
    }

    private func classRow(_ cls: SQLStateClass) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(cls.c)
                .font(Theme.codeFont)
                .foregroundStyle(Theme.severityColor(cls.sev ?? "error"))
                .frame(minWidth: 34, alignment: .leading)
            VStack(alignment: .leading, spacing: 3) {
                Text(cls.t).font(.subheadline.weight(.semibold))
                Text(cls.d).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
        }
        .padding(.vertical, 2)
    }

    private func valueRow(_ v: SQLStateValue) -> some View {
        HStack(alignment: .top, spacing: 12) {
            SQLStateChip(value: v.v)
            VStack(alignment: .leading, spacing: 3) {
                Text(v.t).font(.subheadline)
                if let codes = v.codes, !codes.isEmpty {
                    Text("SQLCODE " + codes.joined(separator: ", "))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - One SQLSTATE value

struct SQLStateDetailView: View {
    let value: String

    @EnvironmentObject private var store: DataStore
    @State private var platform: DB2Platform? = nil

    private var definitions: [SQLStateValue] {
        store.sqlState?.specific.filter { $0.v.uppercased() == value.uppercased() } ?? []
    }

    private var cls: SQLStateClass? {
        store.sqlState?.classes.first { $0.c == String(value.prefix(2)) }
    }

    private var codes: [DB2Code] { store.codes(forSQLState: value, platform: platform) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Text(value)
                        .font(.system(size: 34, weight: .bold, design: .monospaced))
                        .foregroundStyle(Theme.severityColor(cls?.sev ?? "error"))
                    if let cls {
                        Text("Class \(cls.c) — \(cls.t)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }

                if let cls {
                    Card(title: "Class", systemImage: "square.stack.3d.up") {
                        Text(cls.d).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                        if let a = cls.a {
                            Text(a).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }

                ForEach(definitions) { def in
                    Card(title: "Meaning", systemImage: "text.book.closed") {
                        Text(def.t).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                    }
                }

                Card(title: "Codes that raise this state", systemImage: "number.square", accent: Theme.severityColor(cls?.sev ?? "error")) {
                    Picker("Platform", selection: $platform) {
                        Text("Both").tag(DB2Platform?.none)
                        Text("z/OS").tag(DB2Platform?.some(.zos))
                        Text("LUW").tag(DB2Platform?.some(.luw))
                    }
                    .pickerStyle(.segmented)

                    if codes.isEmpty {
                        Text("No code in the bundled dataset lists this SQLSTATE (it may be raised by an external routine or a non-SQL component).")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        VStack(spacing: 0) {
                            ForEach(codes.prefix(80)) { c in
                                NavigationLink(value: Route.code(c)) {
                                    CodeRow(code: c)
                                }
                                .buttonStyle(.plain)
                                if c.id != codes.prefix(80).last?.id { Divider() }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 24)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("SQLSTATE \(value)")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - One SQLSTATE class

struct SQLStateClassDetailView: View {
    let cls: SQLStateClass
    @EnvironmentObject private var store: DataStore
    @State private var platform: DB2Platform? = nil

    private var codes: [DB2Code] {
        store.allCodes
            .filter { $0.s.contains { $0.hasPrefix(cls.c) } && (platform == nil || $0.platform == platform) }
            .sorted { abs($0.c) < abs($1.c) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Text(cls.c)
                        .font(.system(size: 34, weight: .bold, design: .monospaced))
                        .foregroundStyle(Theme.severityColor(cls.sev ?? "error"))
                    Text(cls.t).font(.headline)
                    Spacer()
                }

                Card(title: "What this class means", systemImage: "info.circle") {
                    Text(cls.d).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                    if let a = cls.a {
                        Text(a).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }

                if let reps = cls.codes, !reps.isEmpty {
                    Card(title: "Representative SQLCODEs", systemImage: "number") {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(reps, id: \.self) { label in
                                    let n = Int(label.replacingOccurrences(of: "+", with: ""))
                                    if let n, let target = store.code(n, platform: platform ?? .zos) ?? store.code(n, platform: .luw) {
                                        NavigationLink(value: Route.code(target)) {
                                            Text(label)
                                                .font(Theme.smallMono.weight(.semibold))
                                                .padding(.horizontal, 10).padding(.vertical, 6)
                                                .background(Color.accentColor.opacity(0.12))
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                    }
                }

                Card(title: "All \(codes.count) codes in this class", systemImage: "list.bullet") {
                    Picker("Platform", selection: $platform) {
                        Text("Both").tag(DB2Platform?.none)
                        Text("z/OS").tag(DB2Platform?.some(.zos))
                        Text("LUW").tag(DB2Platform?.some(.luw))
                    }
                    .pickerStyle(.segmented)

                    VStack(spacing: 0) {
                        ForEach(codes) { c in
                            NavigationLink(value: Route.code(c)) {
                                CodeRow(code: c)
                            }
                            .buttonStyle(.plain)
                            if c.id != codes.last?.id { Divider() }
                        }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 24)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Class \(cls.c)")
        .navigationBarTitleDisplayMode(.inline)
    }
}
