//
//  CodeDetailView.swift
//  Everything known about one SQLCODE: message, SQLSTATE, class, causes, fixes, examples.
//

import SwiftUI

struct CodeDetailView: View {
    let initial: DB2Code

    @EnvironmentObject private var store: DataStore
    @EnvironmentObject private var favourites: FavouritesStore
    @State private var platform: DB2Platform

    init(code: DB2Code) {
        self.initial = code
        _platform = State(initialValue: code.platform)
    }

    private var variants: [DB2Code] { store.variants(of: initial) }
    private var code: DB2Code { variants.first { $0.platform == platform } ?? initial }
    private var guidance: Guidance? { store.guidance(for: code) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                header
                if variants.count > 1 { platformPicker }
                messageCard
                if let guidance { guidanceCards(guidance) } else { fallbackCard }
                sqlstateCard
                relatedCard
                docsCard
            }
            .padding(.horizontal)
            .padding(.bottom, 28)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle(code.codeLabel)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    favourites.toggle(code)
                } label: {
                    Image(systemName: favourites.contains(code) ? "bookmark.fill" : "bookmark")
                }
                .accessibilityLabel(favourites.contains(code) ? "Remove bookmark" : "Add bookmark")
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                ShareLink(item: shareText) {
                    Image(systemName: "square.and.arrow.up")
                }
            }
        }
    }

    // MARK: - Sections

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text(code.codeLabel)
                    .font(.system(size: 40, weight: .bold, design: .monospaced))
                    .foregroundStyle(Theme.severityColor(code.severity))
                VStack(alignment: .leading, spacing: 4) {
                    SeverityBadge(severity: code.severity)
                    HStack(spacing: 6) {
                        PlatformBadge(platform: code.platform)
                        if let m = code.m { TagChip(text: m) }
                    }
                }
                Spacer()
            }
            HStack(spacing: 6) {
                TagChip(text: code.k, color: .accentColor)
                Text("Severity letter: \(code.v ?? (code.c > 0 ? "W" : "N"))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.top, 4)
    }

    private var platformPicker: some View {
        Picker("Platform", selection: $platform) {
            ForEach(variants) { variant in
                Text(variant.platform.title).tag(variant.platform)
            }
        }
        .pickerStyle(.segmented)
    }

    private var messageCard: some View {
        Card(title: "Message", systemImage: "text.quote") {
            Text(code.t)
                .font(.callout)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                CopyButton(text: "SQLCODE \(code.codeLabel) · SQLSTATE \(code.s.joined(separator: ", "))\n\(code.t)")
                if let e = guidance?.example { CopyButton(text: e, label: "Copy example") }
            }
        }
    }

    @ViewBuilder
    private func guidanceCards(_ g: Guidance) -> some View {
        if let summary = g.summary {
            Card(title: "What it means", systemImage: "info.circle", accent: Theme.severityColor(code.severity)) {
                Text(summary)
                    .font(.subheadline)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        if let causes = g.causes, !causes.isEmpty {
            Card(title: "Typical causes", systemImage: "exclamationmark.magnifyingglass", accent: Theme.warn) {
                BulletList(items: causes, symbol: "circle.fill", tint: Theme.warn)
            }
        }
        if let fixes = g.fixes, !fixes.isEmpty {
            Card(title: "How to fix it", systemImage: "wrench.and.screwdriver", accent: Theme.ok) {
                NumberedList(items: fixes)
            }
        }
        if let example = g.example {
            Card(title: "Example", systemImage: "curlybraces", accent: Theme.zos) {
                CodeBlock(code: example)
            }
        }
        if let rc = g.reasonCodes, !rc.isEmpty {
            Card(title: "Reason codes", systemImage: "list.number", accent: Theme.luw) {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(rc) { item in
                        HStack(alignment: .top, spacing: 8) {
                            Text(item.code)
                                .font(Theme.smallMono.weight(.semibold))
                                .foregroundStyle(Theme.luw)
                            Text(item.meaning)
                                .font(.subheadline)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
            }
        }
    }

    private var fallbackCard: some View {
        Card(title: "What to check", systemImage: "checklist", accent: Theme.warn) {
            VStack(alignment: .leading, spacing: 10) {
                if let hint = code.hint {
                    Text(hint).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                }
                Text("Message text and SQLSTATE come from the IBM Db2 codes documentation. For the full explanation and user response of this code, use the documentation link below — and add your own note here once you have solved it in your environment.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let e = code.hint {
                    CopyButton(text: "SQLCODE \(code.codeLabel) (\(code.k)) — \(e)", label: "Copy summary")
                }
            }
        }
    }

    private var sqlstateCard: some View {
        Card(title: "SQLSTATE", systemImage: "number", accent: .accentColor) {
            if code.s.isEmpty {
                Text("No SQLSTATE is recorded for this code in the documentation.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(code.s, id: \.self) { st in
                        NavigationLink(value: Route.sqlstate(st)) {
                            HStack {
                                SQLStateChip(value: st)
                                let cls = store.sqlState?.classes.first { $0.c == String(st.prefix(2)) }
                                Text(cls?.t ?? "SQLSTATE class \(st.prefix(2))")
                                    .font(.subheadline)
                                    .foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var relatedCard: some View {
        let classCodes = code.s.first.map { store.codes(inClassOf: $0, platform: code.platform) } ?? []
        let related = Array(classCodes.filter { $0.c != code.c }.prefix(12))
        let seeAlso = guidance?.seeAlso?.compactMap { label -> DB2Code? in
            let n = Int(label.replacingOccurrences(of: "+", with: ""))
            return n.flatMap { store.code($0, platform: code.platform) ?? store.code($0, platform: code.platform == .zos ? .luw : .zos) }
        } ?? []

        return Group {
            if !seeAlso.isEmpty || related.count > 1 {
                Card(title: "Related codes", systemImage: "point.3.connected.trianglepath.dotted") {
                    VStack(alignment: .leading, spacing: 8) {
                        if !seeAlso.isEmpty {
                            Text("Often seen with").font(.caption).foregroundStyle(.secondary)
                            chipRow(seeAlso)
                        }
                        if related.count > 1 {
                            Text("Same SQLSTATE class").font(.caption).foregroundStyle(.secondary)
                            chipRow(related)
                        }
                    }
                }
            }
        }
    }

    private func chipRow(_ codes: [DB2Code]) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(codes) { c in
                    NavigationLink(value: Route.code(c)) {
                        Text(c.codeLabel)
                            .font(Theme.smallMono.weight(.semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Theme.severityColor(c.severity).opacity(0.12))
                            .foregroundStyle(Theme.severityColor(c.severity))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var docsCard: some View {
        Card(title: "Documentation", systemImage: "book") {
            VStack(alignment: .leading, spacing: 8) {
                if code.platform == .zos {
                    Link(destination: URL(string: "https://www.ibm.com/docs/en/db2-for-zos/13?topic=db2-codes")!) {
                        Label("Db2 for z/OS — Codes (IBM Documentation)", systemImage: "arrow.up.right.square")
                            .font(.footnote)
                    }
                } else {
                    Link(destination: URL(string: "https://www.ibm.com/docs/en/db2/11.5.x?topic=messages-sql-codes")!) {
                        Label("Db2 for LUW — SQL codes (IBM Documentation)", systemImage: "arrow.up.right.square")
                            .font(.footnote)
                    }
                }
                Link(destination: URL(string: "https://www.ibm.com/docs/en/db2-for-zos/13?topic=codes-sqlstate-values-common-error")!) {
                    Label("SQLSTATE values and common error codes", systemImage: "arrow.up.right.square")
                        .font(.footnote)
                }
            }
        }
    }

    private var shareText: String {
        var parts = ["SQLCODE \(code.codeLabel) — \(code.platform.title)"]
        if let m = code.m { parts.append("Message: \(m)") }
        if !code.s.isEmpty { parts.append("SQLSTATE: \(code.s.joined(separator: ", "))") }
        parts.append(code.t)
        if let g = guidance {
            if let s = g.summary { parts.append("\nMeaning: \(s)") }
            if let f = g.fixes, !f.isEmpty { parts.append("\nFix: " + f.joined(separator: " ")) }
        }
        parts.append("\n— SQLCODE Atlas (offline Db2 reference)")
        return parts.joined(separator: "\n")
    }
}
