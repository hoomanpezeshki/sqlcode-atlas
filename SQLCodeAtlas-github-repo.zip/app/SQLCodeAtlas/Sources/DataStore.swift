//
//  DataStore.swift
//  Loads the bundled Db2 SQLCODE / SQLSTATE / statement datasets and provides search.
//

import Foundation
import SwiftUI
import Combine

/// Loaded once at start-up and only touched from the main actor (views).
final class DataStore: ObservableObject {

    // Raw data
    @Published private(set) var zosCodes: [DB2Code] = []
    @Published private(set) var luwCodes: [DB2Code] = []
    @Published private(set) var guidance: [String: Guidance] = [:]
    @Published private(set) var sqlState: SQLStateFile?
    @Published private(set) var statements: StatementFile?
    @Published private(set) var meta: MetaFile?

    @Published private(set) var isLoaded = false
    @Published private(set) var loadError: String?

    /// lower-cased message text cache for fast searching
    private var searchIndex: [(code: DB2Code, lower: String)] = []

    // MARK: - Loading

    func loadIfNeeded() {
        guard !isLoaded, loadError == nil else { return }
        do {
            zosCodes = try Self.decodeArray("codes_zos", bundle: .main).map { $0.withPlatform(.zos) }
            luwCodes = try Self.decodeArray("codes_luw", bundle: .main).map { $0.withPlatform(.luw) }
            guidance = Self.flatten(try Self.decodeGuidance())
            sqlState = try Self.decode("sqlstate")
            statements = try Self.decode("statements")
            meta = try Self.decode("meta")
            rebuildIndex()
            isLoaded = true
        } catch {
            loadError = error.localizedDescription
        }
    }

    private static func bundleURL(_ name: String, bundle: Bundle = .main) -> URL? {
        bundle.url(forResource: name, withExtension: "json")
    }

    private static func decode<T: Decodable>(_ name: String) throws -> T {
        guard let url = bundleURL(name) else {
            throw NSError(domain: "SQLCodeAtlas", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Missing bundled resource \(name).json"])
        }
        return try JSONDecoder().decode(T.self, from: try Data(contentsOf: url))
    }

    private static func decodeArray(_ name: String, bundle: Bundle) throws -> [DB2Code] {
        guard let url = bundleURL(name, bundle: bundle) else {
            throw NSError(domain: "SQLCodeAtlas", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Missing bundled resource \(name).json"])
        }
        return try JSONDecoder().decode([DB2Code].self, from: try Data(contentsOf: url))
    }

    private static func decodeGuidance() throws -> GuidanceFile {
        guard let url = bundleURL("guidance") else {
            throw NSError(domain: "SQLCodeAtlas", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Missing bundled resource guidance.json"])
        }
        return try JSONDecoder().decode(GuidanceFile.self, from: try Data(contentsOf: url))
    }

    /// "any"/"zos"/"luw" dictionaries -> single flat dictionary keyed "any:-803", "zos:-803", ...
    private static func flatten(_ file: GuidanceFile) -> [String: Guidance] {
        var out: [String: Guidance] = [:]
        for (platform, entries) in file {
            for (code, g) in entries where !g.isEmpty {
                out["\(platform):\(code)"] = g
            }
        }
        return out
    }

    private func rebuildIndex() {
        let all = zosCodes + luwCodes
        searchIndex = all.map { ($0, ($0.t + " " + $0.k + " " + ($0.m ?? "")).lowercased()) }
    }

    // MARK: - Lookups

    var allCodes: [DB2Code] { zosCodes + luwCodes }

    func codes(for platform: DB2Platform?) -> [DB2Code] {
        switch platform {
        case .none:  return (zosCodes + luwCodes).sorted { $0.c == $1.c ? $0.platform.rawValue < $1.platform.rawValue : $0.c < $1.c }
        case .zos?:  return zosCodes
        case .luw?:  return luwCodes
        }
    }

    /// All platform variants of a given numeric code (used by the detail screen tabs).
    func variants(of code: DB2Code) -> [DB2Code] {
        var out: [DB2Code] = []
        if let z = zosCodes.first(where: { $0.c == code.c }) { out.append(z) }
        if let l = luwCodes.first(where: { $0.c == code.c }) { out.append(l) }
        return out
    }

    func code(_ value: Int, platform: DB2Platform) -> DB2Code? {
        codes(for: platform).first { $0.c == value }
    }

    func guidance(for code: DB2Code) -> Guidance? {
        guidance["\(code.platform.rawValue):\(code.c)"] ?? guidance["any:\(code.c)"]
    }

    func hasAuthoredGuidance(_ code: DB2Code) -> Bool { guidance(for: code) != nil }

    // MARK: - Search

    /// Smart search: "803", "-803", "SQL0803N", "23505", "deadlock", "cursor not open"
    func search(_ raw: String, platform: DB2Platform?) -> [CodeHit] {
        let q = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return [] }
        let lower = q.lowercased()
        let digits = q.filter { $0.isNumber }
        let isNumeric = !digits.isEmpty && lower.allSatisfy { $0.isNumber || $0 == "-" || $0 == "+" || $0 == " " }

        var hits: [CodeHit] = []
        for entry in searchIndex {
            let code = entry.code
            if let platform, code.platform != platform { continue }

            var kind: CodeHit.MatchKind?

            if isNumeric, let wanted = Int(digits) {
                if code.c == wanted { kind = .exactCode }
                else if "\(abs(code.c))".hasPrefix(digits) { kind = .codePrefix }
            }
            if kind == nil, !isNumeric {
                let st = code.s.map { $0.lowercased() }
                if st.contains(lower) { kind = .sqlstate }
                else if let mid = code.m, mid.lowercased() == lower || mid.lowercased().hasPrefix(lower) { kind = .messageID }
                else if entry.lower.contains(lower) { kind = .message }
                else if code.k.lowercased().contains(lower) { kind = .category }
            }
            // SQLSTATE search even when the query looks numeric-ish ("23505")
            if kind == nil, code.s.contains(q.uppercased()) { kind = .sqlstate }

            if let kind { hits.append(CodeHit(code: code, kind: kind)) }
        }

        return hits.sorted { lhs, rhs in
            if lhs.kind.rawValue != rhs.kind.rawValue { return lhs.kind.rawValue < rhs.kind.rawValue }
            if abs(lhs.code.c) != abs(rhs.code.c) { return abs(lhs.code.c) < abs(rhs.code.c) }
            return lhs.code.platform.rawValue < rhs.code.platform.rawValue
        }
    }

    /// Codes that reference a given SQLSTATE (used when drilling down from the SQLSTATE tab).
    func codes(forSQLState value: String, platform: DB2Platform?) -> [DB2Code] {
        let wanted = value.uppercased()
        return allCodes
            .filter { ($0.s.contains(wanted)) && (platform == nil || $0.platform == platform) }
            .sorted { abs($0.c) < abs($1.c) }
    }

    /// Codes in the same class as the argument (e.g. all "23xxx" constraint codes).
    func codes(inClassOf sqlState: String, platform: DB2Platform?) -> [DB2Code] {
        let cls = String(sqlState.uppercased().prefix(2))
        return allCodes
            .filter { ($0.s.contains { $0.hasPrefix(cls) }) && (platform == nil || $0.platform == platform) }
            .sorted { abs($0.c) < abs($1.c) }
    }

    func codes(withCategory category: String, platform: DB2Platform?) -> [DB2Code] {
        codes(for: platform).filter { $0.k == category }
    }

    var categories: [String] {
        Array(Set(allCodes.map { $0.k })).sorted()
    }

    // MARK: - Statistics

    var coverageSummary: String {
        guard let meta else { return "" }
        return "\(meta.zos.codes) z/OS codes · \(meta.luw.codes) LUW codes"
    }
}

// MARK: - Favourites

final class FavouritesStore: ObservableObject {
    private static let key = "sqlcodeatlas.favourites"
    @Published private(set) var ids: Set<String>

    init() {
        let stored = UserDefaults.standard.stringArray(forKey: Self.key) ?? []
        ids = Set(stored)
    }

    func contains(_ code: DB2Code) -> Bool { ids.contains(code.id) }

    func toggle(_ code: DB2Code) {
        if ids.contains(code.id) { ids.remove(code.id) } else { ids.insert(code.id) }
        UserDefaults.standard.set(Array(ids), forKey: Self.key)
    }
}
