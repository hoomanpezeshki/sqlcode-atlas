//
//  SQLCodeAtlasApp.swift
//  Entry point and navigation shell.
//

import SwiftUI

// MARK: - Routes

enum Route: Hashable {
    case code(DB2Code)
    case sqlstate(String)
    case sqlstateClass(SQLStateClass)
    case statement(SQLStatement)
}

// MARK: - App

@main
struct SQLCodeAtlasApp: App {
    @StateObject private var store = DataStore()
    @StateObject private var favourites = FavouritesStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(favourites)
                .task { store.loadIfNeeded() }
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var store: DataStore
    @State private var selection = 0

    var body: some View {
        Group {
            if store.isLoaded {
                TabView(selection: $selection) {
                    HomeView()
                        .tabItem { Label("Home", systemImage: "house") }
                        .tag(0)

                    CodesView()
                        .tabItem { Label("SQLCODEs", systemImage: "number.square") }
                        .tag(1)

                    SQLStateView()
                        .tabItem { Label("SQLSTATE", systemImage: "text.magnifyingglass") }
                        .tag(2)

                    StatementsView()
                        .tabItem { Label("Statements", systemImage: "curlybraces") }
                        .tag(3)

                    AboutView()
                        .tabItem { Label("About", systemImage: "info.circle") }
                        .tag(4)
                }
            } else if let error = store.loadError {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.largeTitle)
                        .foregroundStyle(Theme.error)
                    Text("Could not load the Db2 reference data")
                        .font(.headline)
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .padding()
            } else {
                VStack(spacing: 14) {
                    ProgressView()
                    Text("Loading Db2 codes…")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}
