#!/usr/bin/env python3
"""
Generate app/SQLCodeAtlas.xcodeproj/project.pbxproj without needing Xcode or XcodeGen.

Run:  python3 tools/gen_xcodeproj.py

Creates:
  SQLCodeAtlas.xcodeproj/project.pbxproj        (openable by Xcode 15/16+)
  SQLCodeAtlas.xcodeproj/xcshareddata/xcschemes/SQLCodeAtlas.xcscheme
"""
import os, glob, hashlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # app/
PROJ = os.path.join(ROOT, "SQLCodeAtlas.xcodeproj")
APP  = "SQLCodeAtlas"

def oid(*parts):
    """Deterministic 24-hex-character object id."""
    return hashlib.sha1("::".join(parts).encode()).hexdigest()[:24].upper()

# ---------------------------------------------------------------- collect files
swift_files = sorted(glob.glob(os.path.join(ROOT, APP, "Sources", "**", "*.swift"), recursive=True))
json_files  = sorted(glob.glob(os.path.join(ROOT, APP, "Resources", "*.json")))

def rel(p):
    return os.path.relpath(p, ROOT).replace(os.sep, "/")

entries = []          # (group_name, path_rel, filetype, build_phase)
for f in swift_files:
    entries.append(("Sources", rel(f), "sourcecode.swift", "sources"))
for f in json_files:
    entries.append(("Resources", rel(f), "text.json", "resources"))

# ---------------------------------------------------------------- ids
ids = {
    "project":        oid("project"),
    "mainGroup":      oid("mainGroup"),
    "productsGroup":  oid("productsGroup"),
    "appGroup":       oid("appGroup"),
    "sourcesGroup":   oid("sourcesGroup"),
    "resourcesGroup": oid("resourcesGroup"),
    "target":         oid("target"),
    "productRef":     oid("productRef"),
    "sourcesPhase":   oid("sourcesPhase"),
    "resourcesPhase": oid("resourcesPhase"),
    "frameworksPhase":oid("frameworksPhase"),
    "projConfigList": oid("projConfigList"),
    "tgtConfigList":  oid("tgtConfigList"),
    "projDebug":      oid("projDebug"),
    "projRelease":    oid("projRelease"),
    "tgtDebug":       oid("tgtDebug"),
    "tgtRelease":     oid("tgtRelease"),
    "assetsRef":      oid("assetsRef"),
    "assetsBuild":    oid("assetsBuild"),
    "infoRef":        oid("infoRef"),
}
file_refs, build_files = {}, {}
for group, path, ftype, phase in entries:
    file_refs[path] = oid("fileref", path)
    build_files[path] = oid("buildfile", path)

# ---------------------------------------------------------------- sections
def file_ref_block():
    lines = []
    for group, path, ftype, phase in entries:
        lines.append(f'\t\t{file_refs[path]} /* {os.path.basename(path)} */ = {{isa = PBXFileReference; lastKnownFileType = {ftype}; path = "{os.path.basename(path)}"; sourceTree = "<group>"; }};')
    lines.append(f'\t\t{ids["productRef"]} /* {APP}.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = "{APP}.app"; sourceTree = BUILT_PRODUCTS_DIR; }};')
    lines.append(f'\t\t{ids["assetsRef"]} /* Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = "Assets.xcassets"; sourceTree = "<group>"; }};')
    lines.append(f'\t\t{ids["infoRef"]} /* Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = "Info.plist"; sourceTree = "<group>"; }};')
    return "\n".join(lines)

def build_file_block():
    lines = []
    for group, path, ftype, phase in entries:
        lines.append(f'\t\t{build_files[path]} /* {os.path.basename(path)} in {phase.capitalize()} */ = {{isa = PBXBuildFile; fileRef = {file_refs[path]} /* {os.path.basename(path)} */; }};')
    lines.append(f'\t\t{ids["assetsBuild"]} /* Assets.xcassets in Resources */ = {{isa = PBXBuildFile; fileRef = {ids["assetsRef"]} /* Assets.xcassets */; }};')
    return "\n".join(lines)

def group_children(group):
    out = []
    for g, path, ftype, phase in entries:
        if g == group:
            out.append(f'\t\t\t\t{file_refs[path]} /* {os.path.basename(path)} */,')
    return "\n".join(out)

def phase_files(phase):
    out = []
    for g, path, ftype, ph in entries:
        if ph == phase:
            out.append(f'\t\t\t\t{build_files[path]} /* {os.path.basename(path)} in {phase.capitalize()} */,')
    return "\n".join(out)

pbx = f'''// !$*UTF8*$!
{{
	archiveVersion = 1;
	classes = {{
	}};
	objectVersion = 56;
	objects = {{

/* Begin PBXBuildFile section */
{build_file_block()}
/* End PBXBuildFile section */

/* Begin PBXFileReference section */
{file_ref_block()}
/* End PBXFileReference section */

/* Begin PBXFrameworksBuildPhase section */
		{ids["frameworksPhase"]} /* Frameworks */ = {{
			isa = PBXFrameworksBuildPhase;
			buildActionMask = 2147483647;
			files = (
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXFrameworksBuildPhase section */

/* Begin PBXGroup section */
		{ids["mainGroup"]} = {{
			isa = PBXGroup;
			children = (
				{ids["appGroup"]} /* {APP} */,
				{ids["productsGroup"]} /* Products */,
			);
			sourceTree = "<group>";
		}};
		{ids["productsGroup"]} /* Products */ = {{
			isa = PBXGroup;
			children = (
				{ids["productRef"]} /* {APP}.app */,
			);
			name = Products;
			sourceTree = "<group>";
		}};
		{ids["appGroup"]} /* {APP} */ = {{
			isa = PBXGroup;
			children = (
				{ids["sourcesGroup"]} /* Sources */,
				{ids["resourcesGroup"]} /* Resources */,
				{ids["assetsRef"]} /* Assets.xcassets */,
				{ids["infoRef"]} /* Info.plist */,
			);
			path = {APP};
			sourceTree = "<group>";
		}};
		{ids["sourcesGroup"]} /* Sources */ = {{
			isa = PBXGroup;
			children = (
{group_children("Sources")}
			);
			path = Sources;
			sourceTree = "<group>";
		}};
		{ids["resourcesGroup"]} /* Resources */ = {{
			isa = PBXGroup;
			children = (
{group_children("Resources")}
			);
			path = Resources;
			sourceTree = "<group>";
		}};
/* End PBXGroup section */

/* Begin PBXNativeTarget section */
		{ids["target"]} /* {APP} */ = {{
			isa = PBXNativeTarget;
			buildConfigurationList = {ids["tgtConfigList"]} /* Build configuration list for PBXNativeTarget "{APP}" */;
			buildPhases = (
				{ids["sourcesPhase"]} /* Sources */,
				{ids["frameworksPhase"]} /* Frameworks */,
				{ids["resourcesPhase"]} /* Resources */,
			);
			buildRules = (
			);
			dependencies = (
			);
			name = {APP};
			productName = {APP};
			productReference = {ids["productRef"]} /* {APP}.app */;
			productType = "com.apple.product-type.application";
		}};
/* End PBXNativeTarget section */

/* Begin PBXProject section */
		{ids["project"]} /* Project object */ = {{
			isa = PBXProject;
			attributes = {{
				BuildIndependentTargetsInParallel = 1;
				LastSwiftUpdateCheck = 1500;
				LastUpgradeCheck = 1500;
				TargetAttributes = {{
					{ids["target"]} = {{
						CreatedOnToolsVersion = 15.0;
					}};
				}};
			}};
			buildConfigurationList = {ids["projConfigList"]} /* Build configuration list for PBXProject "{APP}" */;
			compatibilityVersion = "Xcode 14.0";
			developmentRegion = en;
			hasScannedForEncodings = 0;
			knownRegions = (
				en,
				Base,
			);
			mainGroup = {ids["mainGroup"]};
			productRefGroup = {ids["productsGroup"]} /* Products */;
			projectDirPath = "";
			projectRoot = "";
			targets = (
				{ids["target"]} /* {APP} */,
			);
		}};
/* End PBXProject section */

/* Begin PBXResourcesBuildPhase section */
		{ids["resourcesPhase"]} /* Resources */ = {{
			isa = PBXResourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
				{ids["assetsBuild"]} /* Assets.xcassets in Resources */,
{phase_files("resources")}
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXResourcesBuildPhase section */

/* Begin PBXSourcesBuildPhase section */
		{ids["sourcesPhase"]} /* Sources */ = {{
			isa = PBXSourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
{phase_files("sources")}
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXSourcesBuildPhase section */

/* Begin XCBuildConfiguration section */
		{ids["projDebug"]} /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ALWAYS_SEARCH_USER_PATHS = NO;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = dwarf;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				ENABLE_TESTABILITY = YES;
				ENABLE_USER_SCRIPT_SANDBOXING = NO;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_DYNAMIC_NO_PIC = NO;
				GCC_NO_COMMON_BLOCKS = YES;
				GCC_OPTIMIZATION_LEVEL = 0;
				GCC_PREPROCESSOR_DEFINITIONS = (
					"DEBUG=1",
					"$(inherited)",
				);
				IPHONEOS_DEPLOYMENT_TARGET = 16.0;
				MTL_ENABLE_DEBUG_INFO = INCLUDE_SOURCE;
				MTL_FAST_MATH = YES;
				ONLY_ACTIVE_ARCH = YES;
				SDKROOT = iphoneos;
				SWIFT_ACTIVE_COMPILATION_CONDITIONS = "DEBUG $(inherited)";
				SWIFT_OPTIMIZATION_LEVEL = "-Onone";
				SWIFT_VERSION = 5.9;
			}};
			name = Debug;
		}};
		{ids["projRelease"]} /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ALWAYS_SEARCH_USER_PATHS = NO;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym";
				ENABLE_NS_ASSERTIONS = NO;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				ENABLE_USER_SCRIPT_SANDBOXING = NO;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_NO_COMMON_BLOCKS = YES;
				IPHONEOS_DEPLOYMENT_TARGET = 16.0;
				MTL_ENABLE_DEBUG_INFO = NO;
				MTL_FAST_MATH = YES;
				SDKROOT = iphoneos;
				SWIFT_COMPILATION_MODE = wholemodule;
				SWIFT_VERSION = 5.9;
				VALIDATE_PRODUCT = YES;
			}};
			name = Release;
		}};
		{ids["tgtDebug"]} /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
				ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor;
				CODE_SIGN_STYLE = Automatic;
				CURRENT_PROJECT_VERSION = 1;
				ENABLE_PREVIEWS = YES;
				GENERATE_INFOPLIST_FILE = NO;
				INFOPLIST_FILE = SQLCodeAtlas/Info.plist;
				LD_RUNPATH_SEARCH_PATHS = (
					"$(inherited)",
					"@executable_path/Frameworks",
				);
				MARKETING_VERSION = 1.0;
				PRODUCT_BUNDLE_IDENTIFIER = com.sqlcodeatlas.app;
				PRODUCT_NAME = "$(TARGET_NAME)";
				SUPPORTS_MACCATALYST = NO;
				SWIFT_EMIT_LOC_STRINGS = YES;
				TARGETED_DEVICE_FAMILY = "1,2";
			}};
			name = Debug;
		}};
		{ids["tgtRelease"]} /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
				ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
				ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor;
				CODE_SIGN_IDENTITY = "-";
				CODE_SIGNING_ALLOWED = YES;
				CODE_SIGNING_REQUIRED = NO;
				CODE_SIGN_STYLE = Automatic;
				CURRENT_PROJECT_VERSION = 1;
				ENABLE_PREVIEWS = YES;
				GENERATE_INFOPLIST_FILE = NO;
				INFOPLIST_FILE = SQLCodeAtlas/Info.plist;
				LD_RUNPATH_SEARCH_PATHS = (
					"$(inherited)",
					"@executable_path/Frameworks",
				);
				MARKETING_VERSION = 1.0;
				PRODUCT_BUNDLE_IDENTIFIER = com.sqlcodeatlas.app;
				PRODUCT_NAME = "$(TARGET_NAME)";
				SUPPORTS_MACCATALYST = NO;
				SWIFT_EMIT_LOC_STRINGS = YES;
				TARGETED_DEVICE_FAMILY = "1,2";
			}};
			name = Release;
		}};
/* End XCBuildConfiguration section */

/* Begin XCConfigurationList section */
		{ids["projConfigList"]} /* Build configuration list for PBXProject "{APP}" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{ids["projDebug"]} /* Debug */,
				{ids["projRelease"]} /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
		{ids["tgtConfigList"]} /* Build configuration list for PBXNativeTarget "{APP}" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{ids["tgtDebug"]} /* Debug */,
				{ids["tgtRelease"]} /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
/* End XCConfigurationList section */
	}};
	rootObject = {ids["project"]} /* Project object */;
}}
'''

os.makedirs(PROJ, exist_ok=True)
with open(os.path.join(PROJ, "project.pbxproj"), "w", encoding="utf-8") as fh:
    fh.write(pbx)

# ---------------------------------------------------------------- shared scheme
scheme_dir = os.path.join(PROJ, "xcshareddata", "xcschemes")
os.makedirs(scheme_dir, exist_ok=True)
scheme = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion = "1500" version = "1.7">
   <BuildAction parallelizeBuildables = "YES" buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry buildForTesting = "YES" buildForRunning = "YES" buildForProfiling = "YES" buildForArchiving = "YES" buildForAnalyzing = "YES">
            <BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{ids["target"]}"
               BuildableName = "{APP}.app"
               BlueprintName = "{APP}"
               ReferencedContainer = "container:{APP}.xcodeproj">
            </BuildableReference>
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction buildConfiguration = "Debug" selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction buildConfiguration = "Debug" selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB" launchStyle = "0" useCustomWorkingDirectory = "NO" ignoresPersistentStateOnLaunch = "NO" debugDocumentVersioning = "YES" debugServiceExtension = "internal" allowLocationSimulation = "YES">
      <BuildableProductRunnable runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{ids["target"]}"
            BuildableName = "{APP}.app"
            BlueprintName = "{APP}"
            ReferencedContainer = "container:{APP}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction buildConfiguration = "Release" shouldUseLaunchSchemeArgsEnv = "YES" savedToolIdentifier = "" useCustomWorkingDirectory = "NO" debugDocumentVersioning = "YES">
      <BuildableProductRunnable runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{ids["target"]}"
            BuildableName = "{APP}.app"
            BlueprintName = "{APP}"
            ReferencedContainer = "container:{APP}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction buildConfiguration = "Release" revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
'''
with open(os.path.join(scheme_dir, f"{APP}.xcscheme"), "w", encoding="utf-8") as fh:
    fh.write(scheme)

print(f"project written : {os.path.join(PROJ, 'project.pbxproj')}")
print(f"scheme written  : {os.path.join(scheme_dir, APP + '.xcscheme')}")
print(f"sources         : {len(swift_files)} swift files")
print(f"resources       : {len(json_files)} json files -> " + ", ".join(os.path.basename(f) for f in json_files))
