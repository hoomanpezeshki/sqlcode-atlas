#!/usr/bin/env python3
"""
Validate the bundled datasets against the contract expected by the Swift models
(Models.swift / DataStore.swift). Safe to run anywhere - no Xcode required.

    python3 tools/validate_data.py
"""
import json, os, sys, glob, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES  = os.path.join(ROOT, "SQLCodeAtlas", "Resources")
errors, warnings = [], []

def load(name):
    p = os.path.join(RES, name)
    if not os.path.exists(p):
        errors.append(f"missing resource {name}")
        return None
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception as exc:
        errors.append(f"{name} is not valid JSON: {exc}")
        return None

def check_codes(name, records, expect_msgid):
    if records is None:
        return set()
    seen = set()
    for r in records:
        where = f"{name}:{r.get('c')}"
        for key, typ in (("c", int), ("t", str), ("s", list), ("k", str), ("g", str)):
            if key not in r:
                errors.append(f"{where} missing key '{key}'")
            elif not isinstance(r[key], typ):
                errors.append(f"{where} key '{key}' has type {type(r[key]).__name__}, expected {typ.__name__}")
        if not isinstance(r.get("c"), int) or r.get("c") == 0 and name == "codes_luw.json":
            pass
        if r.get("c") in seen:
            warnings.append(f"{where} duplicate SQLCODE in {name}")
        seen.add(r.get("c"))
        for st in r.get("s", []):
            if not re.fullmatch(r"[0-9A-Za-z]{5}", st):
                errors.append(f"{where} bad SQLSTATE '{st}'")
        if r.get("g") not in ("success", "nodata", "warning", "error"):
            errors.append(f"{where} bad severity group '{r.get('g')}'")
        if expect_msgid:
            if not r.get("m") or not re.fullmatch(r"SQL\d{4,5}[A-Z]?", r.get("m", "")):
                warnings.append(f"{where} missing/odd LUW message id '{r.get('m')}'")
        if "platform" in r:
            errors.append(f"{where} should not embed 'platform' (the app injects it)")
    return seen

print("validating", RES)
zos = load("codes_zos.json")
luw = load("codes_luw.json")
guid = load("guidance.json")
stmts = load("statements.json")
states = load("sqlstate.json")
meta = load("meta.json")

zos_codes = check_codes("codes_zos.json", zos, expect_msgid=False)
luw_codes = check_codes("codes_luw.json", luw, expect_msgid=True)

if guid:
    for plat in ("any", "zos", "luw"):
        if plat not in guid:
            errors.append(f"guidance.json missing platform bucket '{plat}'")
            continue
        for code, g in guid[plat].items():
            if not re.fullmatch(r"-?\d+", code):
                errors.append(f"guidance.json[{plat}] key '{code}' is not a SQLCODE")
            known = {
                "summary": str, "causes": list, "fixes": list,
                "example": str, "seeAlso": list, "reasonCodes": list,
            }
            for k, typ in known.items():
                if k in g and not isinstance(g[k], typ):
                    errors.append(f"guidance.json[{plat}][{code}].{k} should be {typ.__name__}")
            if not g:
                warnings.append(f"guidance.json[{plat}][{code}] is empty")
            if plat == "any":
                n = int(code)
                if n not in zos_codes and n not in luw_codes:
                    warnings.append(f"guidance 'any:{code}' does not match any bundled code")

if stmts:
    cats = set(stmts.get("categories", []))
    for s in stmts.get("statements", []):
        for key in ("id", "name", "cat", "plat", "tpl"):
            if key not in s:
                errors.append(f"statements.json:{s.get('id')} missing '{key}'")
        if s.get("cat") not in cats:
            errors.append(f"statements.json:{s.get('id')} category '{s.get('cat')}' not in categories list")
        for p in s.get("plat", []):
            if p not in ("zos", "luw"):
                errors.append(f"statements.json:{s.get('id')} bad platform '{p}'")

if states:
    for cls in states.get("classes", []):
        for key in ("c", "t", "d"):
            if key not in cls:
                errors.append(f"sqlstate class {cls.get('c')} missing '{key}'")
        if not re.fullmatch(r"[0-9A-Z]{2}", cls.get("c", "")):
            errors.append(f"sqlstate class '{cls.get('c')}' is not a 2 character class code")
    for v in states.get("specific", []):
        if not re.fullmatch(r"[0-9A-Za-z]{5}", v.get("v", "")):
            errors.append(f"sqlstate value '{v.get('v')}' is not 5 characters")

# every resource referenced by DataStore must exist
for need in ("codes_zos.json", "codes_luw.json", "guidance.json", "statements.json", "sqlstate.json", "meta.json"):
    if not os.path.exists(os.path.join(RES, need)):
        errors.append(f"DataStore expects {need}, which is missing")

print(f"z/OS codes      : {len(zos) if zos else 0}")
print(f"LUW codes       : {len(luw) if luw else 0}")
if guid:
    print(f"guidance        : any={len(guid.get('any', {}))} zos={len(guid.get('zos', {}))} luw={len(guid.get('luw', {}))}")
if stmts:
    print(f"statements      : {len(stmts.get('statements', []))} in {len(stmts.get('categories', []))} categories")
if states:
    print(f"sqlstate        : {len(states.get('classes', []))} classes, {len(states.get('specific', []))} values")

if warnings:
    print("\nWARNINGS")
    for w in warnings[:40]:
        print("  -", w)
    if len(warnings) > 40:
        print(f"  ... and {len(warnings) - 40} more")

if errors:
    print("\nERRORS")
    for e in errors[:60]:
        print("  -", e)
    sys.exit(1)

print("\nOK - all resources valid.")
