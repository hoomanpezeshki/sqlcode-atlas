# SQLCODE Atlas — Db2 z/OS + LUW SQLCODE app for iPhone/iPad

An **offline iOS app** (SwiftUI, iPhone + iPad) that contains the SQLCODE / SQLSTATE
reference for **Db2 for z/OS** and **Db2 for Linux, UNIX and Windows (LUW)** — plus the SQL
statements and troubleshooting actions you actually need when something breaks in production.

Everything ships inside the app: **no network access is required at runtime**.

---

## 1. What is inside the app

| Tab | Contents |
|---|---|
| **Home** | Smart search (code, SQLSTATE, LUW message id, symptom), coverage stats, most-used codes, bookmarks |
| **SQLCODEs** | Complete catalogue with filters: platform (z/OS / LUW / both), severity, error class, “only codes with written guidance” |
| **SQLSTATE** | All SQLSTATE classes + common values, with drill-down to every code that raises them |
| **Statements** | 39 ready-to-copy SQL snippets in 9 categories (query, DML, DDL, transactions, cursors/routines, diagnostics, catalog, utilities, troubleshooting) |
| **About** | Coverage, sources, attribution, documentation links |

Code detail screen: message text, SQLSTATE(s), platform switch (compare z/OS vs LUW wording of the
same code), **what it means / typical causes / how to fix it / example / reason codes**, related
codes in the same SQLSTATE class, bookmarking and share-sheet export.

### Dataset in this build

| Dataset | Count |
|---|---|
| Db2 for z/OS SQLCODEs | **901** (801 negative, 99 positive, code 0) — 887 with SQLSTATE text |
| Db2 for LUW SQLCODEs | **1 649** (1 510 negative, 138 positive) with LUW message id — 1 640 with SQLSTATE |
| Hand-written troubleshooting entries | **197** (causes, fixes, examples, reason codes) |
| Every code carries class-level diagnosis | yes — derived from its SQLSTATE class |
| SQLSTATE classes / values | 47 / 107 |
| SQL statements | 39 |

Numbers are also written to `app/SQLCodeAtlas/Resources/meta.json` and shown in the app.

---

## 2. Getting a runnable IPA — three routes

> An `.ipa` can only be **installed on an iPhone** after it is signed with an Apple
> certificate + provisioning profile for that device. That signing step needs your Apple
> account — it cannot be done from this workspace (no Apple credentials, no macOS).
> Everything else is done for you: the project, the datasets, the build scripts and CI.

### Route A — GitHub Actions (no Mac needed; recommended)

1. Push this folder to a GitHub repository.
2. GitHub ▸ **Actions** ▸ *Build iOS IPA* ▸ **Run workflow**.
3. Download the artifact **`SQLCodeAtlas-unsigned-ipa`** — that is your `.ipa` file.
4. Install it with one of:
   * **Sideloadly** / **AltStore** (Windows or macOS): drag the IPA in, sign with your Apple ID → device.
   * **Xcode ▸ Window ▸ Devices and Simulators**: drop the IPA on the device (Xcode re-signs it).
   * **Apple Configurator**: add the IPA to a device.

   *Or* configure the signing secrets below and let CI produce an already-signed IPA.

### Route B — your Mac, Xcode

```bash
cd app
open SQLCodeAtlas.xcodeproj          # Xcode 15+ ; select your team in Signing & Capabilities
# then: ⌘R for the simulator, or select your iPhone and ⌘R for the device
```

Command line, signed IPA (development / ad-hoc / app-store):

```bash
cd app
DEVELOPMENT_TEAM=ABCDE12345 ./scripts/build_ipa.sh development   # → dist/ipa/SQLCodeAtlas.ipa
```

Unsigned IPA (also what CI produces):

```bash
cd app && ./scripts/make_ipa_unsigned.sh                          # → dist/SQLCodeAtlas-unsigned.ipa
```

### Route C — signed IPA in CI

Add these repository secrets, then run the workflow (the `signed` job activates automatically):

| Secret | Meaning |
|---|---|
| `BUILD_CERTIFICATE_BASE64` | `base64 -i Certificates.p12 \| pbcopy` |
| `P12_PASSWORD` | password of that `.p12` |
| `PROVISIONING_PROFILE_BASE64` | `base64 -i profile.mobileprovision \| pbcopy` |
| `DEVELOPMENT_TEAM` | 10-character Apple Team ID |
| `KEYCHAIN_PASSWORD` | any random string (temporary CI keychain) |

---

## 3. Project layout

```
app/
├── SQLCodeAtlas.xcodeproj/            generated project (open this in Xcode) + shared scheme
├── project.yml                        XcodeGen spec (optional alternative to the .xcodeproj)
├── SQLCodeAtlas/
│   ├── Info.plist
│   ├── Assets.xcassets/               AppIcon (1024) + AccentColor
│   ├── Sources/                       11 Swift files, no third-party dependencies
│   │   ├── SQLCodeAtlasApp.swift      entry point, tab shell, routes
│   │   ├── Models.swift               DB2Code / Guidance / SQLSTATE / statement models
│   │   ├── DataStore.swift            resource loading, search engine, favourites
│   │   ├── Theme.swift                design system (cards, badges, code blocks, copy button)
│   │   └── Views/                     Home, Codes, CodeDetail, SQLState, Statements, About
│   └── Resources/                     6 JSON datasets (~1.0 MB total)
│       ├── codes_zos.json             z/OS SQLCODEs
│       ├── codes_luw.json             LUW SQLCODEs
│       ├── guidance.json              hand-written troubleshooting (any / zos / luw)
│       ├── sqlstate.json              SQLSTATE classes + common values
│       ├── statements.json            SQL statement library
│       └── meta.json                  coverage statistics
├── scripts/
│   ├── build_ipa.sh                   signed IPA (archive + export)
│   └── make_ipa_unsigned.sh           unsigned IPA
└── tools/
    ├── gen_xcodeproj.py               regenerates the .xcodeproj from the file tree
    └── validate_data.py               validates the datasets against the Swift models

github-repo/                           upload-ready GitHub repository (see the Persian install guide)
├── .github/workflows/build-ios.yml    CI at the REPO ROOT (GitHub only reads .github at the root)
├── app/                               the Xcode project
├── README.md
└── install-guide-fa.md                نصب گام‌به‌گام روی آیفون (فارسی)

data-pipeline/                         how the datasets were produced (Python, reproducible)
├── extract_zos.py                     z/OS codes → zos_records.json
├── extract_luw.py                     LUW messages → luw_records.json
├── build_db.py                        merges sources + overlay → app/SQLCodeAtlas/Resources/*.json
├── overlay_part1/2/3.json             the hand-written guidance (197 entries)
├── statements.json, sqlstate_classes.json
├── zos_codes.txt, luw_msg1.txt, luw_msg2.txt   source text of the IBM manuals used
├── make_icon.py                       regenerates the app icon (1024×1024)
└── make_report.py                     regenerates SQLCodeAtlas-data-report.html
```

Regenerate everything:

```bash
python3 data-pipeline/extract_zos.py data-pipeline/zos_codes.txt data-pipeline/zos_records.json
(cd data-pipeline && python3 extract_luw.py luw_msg1.txt luw_msg2.txt)
python3 data-pipeline/build_db.py          # writes app/SQLCodeAtlas/Resources/*.json
python3 app/tools/validate_data.py         # must print: OK - all resources valid.
python3 app/tools/gen_xcodeproj.py         # after adding/removing source files
python3 data-pipeline/make_report.py       # refresh the HTML data report
```

---

## 4. Data sources, extraction quality and attribution

* Code numbers, message text, LUW message ids and SQLSTATE values are **machine-extracted from
  IBM's published Db2 documentation** (Db2 for z/OS *Codes*; Db2 for LUW *Message Reference*
  Vol. 1–2). The extraction scripts contain the parsing rules, including the page-break artefacts
  that had to be filtered (see the comments in `extract_luw.py` / `extract_zos.py`).
* LUW message-id ↔ SQLCODE pairing is **100 % consistent** in this build (verified in the
  pipeline output); z/OS SQLSTATE coverage is 98 % of codes.
* Causes, fixes, examples, reason-code explanations, SQLSTATE class advice and every SQL
  snippet are **original material** written for this app.
* IBM, Db2, z/OS and DB2 are trademarks of IBM Corporation. The app is an **unofficial,
  independent reference** for personal/educational use — not affiliated with or endorsed by IBM.
  Always confirm against the documentation of your exact Db2 release and function level before
  changing a production system.

Related deliverables in this workspace:

* `راهنمای-نصب-FA.md` — **نصب گام‌به‌گام روی آیفون به فارسی** (Windows + GitHub Actions + Sideloadly،
  یا Xcode روی مک) with troubleshooting table.
* `SQLCodeAtlas-github-repo.zip` — upload-ready repository: drop its contents into a new GitHub repo and
  the *Build iOS IPA* workflow produces the `.ipa` artifact for you.
* `SQLCodeAtlas-data-report.html` — a self-contained, searchable data report for the datasets
  (open it in any browser; useful to review coverage before publishing).
* `SQLCodeAtlas-iOS-app.zip` — the complete project (app + data pipeline) as a single download.

---

## 5. Known limitations / good next steps

* The z/OS dataset contains every code that could be extracted from the *Codes* manual text;
  a handful of the rarer messages live only in other manuals (they are listed in `meta.json` terms
  of counts, not promised per code). Adding a code is a two-line edit in `build_db.py`/overlay.
* The app currently shows IBM's message text verbatim (z/OS messages are upper case). Localisation,
  dark-mode refinements and per-code personal notes are natural next features.
* No analytics, no tracking, no network calls — the app works in air-gapped environments.
